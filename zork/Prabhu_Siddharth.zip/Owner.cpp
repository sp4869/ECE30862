#include "Owner.h"
#include <iostream>
#include <string>

using namespace std;

Owner::Owner()
{
	
}

string Owner::getOwner(){
	return owner;
}


string Owner::getObject(){
	return owner;
}


void Owner::setOwner(string dueno){
	this->owner=dueno;
}


void Owner::has(int has){
	this->has_object= has;
}
