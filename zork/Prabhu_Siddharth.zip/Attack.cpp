#include "Attack.h"
#include <string>
#include <iostream>
#include <vector>
using namespace std;

Attack::Attack()
{
  object = "";
  print = "";
  status = "";
}
void Attack::setPrint(string newPrint)
{
  print = newPrint;
}
void Attack::setObject(string newObject)
{
  object = newObject;
}
void Attack::setStatus(string newStatus)
{
  status = newStatus;
}
void Attack::addAction(string newAction)
{
  actions.push_back(newAction);
}

string Attack::getPrint()
{
  return print;
}
string Attack::getObject()
{
  return object;
}
string Attack::getStatus()
{
  return this ->status;
}
vector <string> Attack::getActions()
{
  return actions;
}

