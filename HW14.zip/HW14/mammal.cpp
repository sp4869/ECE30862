#include <string>
#include <iostream>
#include "mammal.h"
using namespace std;

Mammal::~Mammal(){}
int  Mammal::getlegs(){
  return legs;
}
void Mammal::setlegs(int a){
  legs = a;
}
