#ifndef Mammal_H
#define Mammal_H
#include <iostream>
#include <string>
using namespace std;

class Mammal {
private:
       int legs;
public:
       Mammal();
      ~Mammal();
      void setlegs(int a);
      //irtual void getlegs();
      int getlegs();
};


#endif /* BASE_H */

