#include <string>
#include <iostream>
#include "mammal.h"
using namespace std;

Mammal::~Mammal(){}
Mammal::Mammal(int a){
  legs = a;
 }
int final Mammal::getlegs(){
  return legs;
}


