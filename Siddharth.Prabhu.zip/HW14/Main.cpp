#include <string>
#include <iostream>
#include "mammal.h"
#include "canine.h"
#include "Pet.h"
using namespace std;
int main(int argc,char * argv[])
{
 
  //  Pet * c = new Pet();
   //  c->breed();

}  
