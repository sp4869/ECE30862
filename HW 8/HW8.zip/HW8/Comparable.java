// The Comparable interface goes here.
