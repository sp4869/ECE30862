import java.lang.Integer;

class Int . . . {

   Integer i;

   public Int(int j) {i = new Integer(j);}

   // Implement the Comparable interface functions here.
   . . . 

}
