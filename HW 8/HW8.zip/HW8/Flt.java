import java.lang.Float;

class Flt . . . {

   Float f; // the value returned by the value method.

   public Flt(float f) {this.f = new Float(f);}

}
